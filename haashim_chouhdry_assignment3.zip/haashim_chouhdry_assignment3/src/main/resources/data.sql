INSERT INTO contacts (full_name, job_type, phone_number, address, email)
VALUES
('Bill Barber', 'Staff', '416-222-3333', '123 Random Ave', 'billy@gmail.com'),
('Sara Wayne', 'Customer', '647-312-5678', '5908 Secret Rd', 'sara@hotmail.com'),
('Lester Crest', 'Staff', '905-432-6087', '349 Lane Ave', 'crest@yahoo.com'),
('Erin Tailor', 'Customer', '416-266-9834', '1754 Crazy St', 'tailor@gmail.com');