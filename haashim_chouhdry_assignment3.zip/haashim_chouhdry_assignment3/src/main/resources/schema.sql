CREATE TABLE contacts (
                          id INT AUTO_INCREMENT PRIMARY KEY,
                          full_name VARCHAR(40),
                          job_type VARCHAR(30),
                          phone_number VARCHAR(30),
                          address VARCHAR(30),
                          email VARCHAR(50)
);